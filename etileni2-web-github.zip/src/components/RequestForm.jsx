import { useRef, useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Alert, AlertTitle, AlertDescription } from "./ui/alert";
import { Icon } from "./Icons";
import { IconDisc } from "./Shared";
import { BUSINESS } from "@/data";
import { cn } from "@/lib/utils";

const FORM_NAME = "cleaning-request";
const EMPTY = { name: "", email: "", phone: "", address: "", requirements: "" };

export default function RequestForm() {
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [photo, setPhoto] = useState(null);
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error
  const fileRef = useRef(null);

  const set = (key) => (e) => setValues((v) => ({ ...v, [key]: e.target.value }));

  function validate() {
    const e = {};
    if (!values.name.trim()) e.name = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) e.email = "Please enter a valid email address.";
    if (values.phone.replace(/\D/g, "").length < 6) e.phone = "Please enter a phone number we can reach you on.";
    if (values.requirements.trim().length < 10) e.requirements = "Please tell us what needs cleaning.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (!validate()) {
      document.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }
    setStatus("sending");

    // Netlify Forms: post the form data back to the site root.
    const body = new FormData();
    body.append("form-name", FORM_NAME);
    // Netlify uses a field called "email" as the reply-to, so a reply from
    // info@etileni2.com goes straight back to the customer.
    body.append("subject", `Cleaning request from ${values.name.trim()}`);
    Object.entries(values).forEach(([k, v]) => body.append(k, v));
    if (photo?.file) body.append("photo", photo.file);

    try {
      const res = await fetch("/", { method: "POST", body });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
    } catch {
      setStatus("error");
    }
  }

  function pick(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhoto({ file, name: file.name, size: Math.round(file.size / 1024), url: URL.createObjectURL(file) });
  }

  function reset() {
    setValues(EMPTY);
    setErrors({});
    setPhoto(null);
    setStatus("idle");
  }

  if (status === "sent") {
    return (
      <Card className="p-6 sm:p-7">
        <Alert variant="success">
          <Icon name="check" size={26} strokeWidth={2.4} className="mt-0.5 shrink-0" />
          <div>
            <AlertTitle className="text-[18px] text-white">Request received</AlertTitle>
            <AlertDescription className="text-white/90">
              Thank you. We have your details and will come back to you with what is possible and what it will cost.
              If it is urgent, call {BUSINESS.phone}.
            </AlertDescription>
          </div>
        </Alert>
        <Button variant="outline" className="mt-5 rounded-full" onClick={reset}>Send another request</Button>
      </Card>
    );
  }

  const Field = ({ id, label, required, full, children }) => (
    <div className={cn("flex flex-col gap-2", full && "sm:col-span-2")}>
      <Label htmlFor={id}>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      {children}
      {errors[id] && <span className="text-[12.5px] font-medium text-destructive">{errors[id]}</span>}
    </div>
  );

  return (
    <Card className="p-6 sm:p-7">
      <form name={FORM_NAME} method="POST" data-netlify="true" netlify-honeypot="bot-field" onSubmit={onSubmit} noValidate>
        <input type="hidden" name="form-name" value={FORM_NAME} />
        <p className="hidden">
          <label>Leave this field empty <input name="bot-field" tabIndex={-1} autoComplete="off" /></label>
        </p>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field id="name" label="Full name" required>
            <Input id="name" name="name" autoComplete="name" placeholder="Arben Krasniqi"
              value={values.name} onChange={set("name")} aria-invalid={!!errors.name} />
          </Field>
          <Field id="email" label="Email" required>
            <Input id="email" name="email" type="email" autoComplete="email" placeholder="arben@example.com"
              value={values.email} onChange={set("email")} aria-invalid={!!errors.email} />
          </Field>
          <Field id="phone" label="Phone number" required>
            <Input id="phone" name="phone" type="tel" autoComplete="tel" placeholder="044 000 000"
              value={values.phone} onChange={set("phone")} aria-invalid={!!errors.phone} />
          </Field>
          <Field id="address" label="Address">
            <Input id="address" name="address" autoComplete="street-address" placeholder="Street, neighbourhood, city"
              value={values.address} onChange={set("address")} />
          </Field>
          <Field id="requirements" label="What do you need cleaned?" required full>
            <Textarea id="requirements" name="requirements" value={values.requirements} onChange={set("requirements")}
              aria-invalid={!!errors.requirements}
              placeholder="Two wool coats and a wedding dress. The dress has a mark near the hem." />
          </Field>

          <div className="flex flex-col gap-2 sm:col-span-2">
            <Label>Photo of the item</Label>
            <button type="button" onClick={() => fileRef.current?.click()}
              className={cn("rounded-lg border border-input p-6 text-center transition-all duration-300 ease-brand",
                "hover:border-ring hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                photo && "bg-muted")}>
              <IconDisc name="upload" size={24} className="mx-auto mb-3" />
              <div className="text-[14.5px] font-semibold">Click to add a photo</div>
              <div className="mt-1 text-[12.5px] text-muted-foreground">
                JPG or PNG, up to 8 MB. Optional, but it helps us quote accurately.
              </div>
              {photo && (
                <div className="mt-4 flex items-center gap-3.5 text-left">
                  <img src={photo.url} alt="" className="h-16 w-16 rounded-md object-cover" />
                  <div>
                    <div className="text-[14px] font-semibold">{photo.name}</div>
                    <div className="text-[12.5px] text-muted-foreground">{photo.size} KB</div>
                  </div>
                </div>
              )}
            </button>
            <input ref={fileRef} name="photo" type="file" accept="image/*" className="hidden" onChange={pick} />
          </div>
        </div>

        {status === "error" && (
          <Alert variant="destructive" className="mt-5">
            <Icon name="info" size={22} className="mt-0.5 shrink-0" />
            <div>
              <AlertTitle>That did not send</AlertTitle>
              <AlertDescription>
                Please try again, or email us directly at{" "}
                <a className="font-semibold underline" href={`mailto:${BUSINESS.email}`}>{BUSINESS.email}</a>.
              </AlertDescription>
            </div>
          </Alert>
        )}

        <div className="mt-6 flex flex-wrap items-center gap-4">
          <Button type="submit" size="lg" className="rounded-full" disabled={status === "sending"}>
            {status === "sending" ? "Sending" : "Send request"}
            <Icon name="arrow" size={17} strokeWidth={2.3} />
          </Button>
          <span className="text-[13px] text-muted-foreground">
            Or call <a className="font-semibold text-primary" href={BUSINESS.phoneHref}>{BUSINESS.phone}</a>
          </span>
        </div>
      </form>
    </Card>
  );
}
