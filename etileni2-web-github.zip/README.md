# Etileni 2

Website for Pastrimi Kimik Etileni 2, N.P.Z Etileni 2, Prishtina.

Vite, React 18, Tailwind CSS 3, react-router-dom 6. Satoshi is self hosted
from `public/fonts`, so the site loads no third party fonts.

## Run it

```bash
npm install
npm run dev      # local dev server
npm run build    # production build into dist/
npm run preview  # serve the built dist/ locally
```

Node 20 or newer.

## Where the content lives

`src/data.js` is the single source of truth. Opening hours, the four
locations, the example prices, the FAQ, the Google reviews and the social
links are all there. Edit that file, not the components.

Social links: a channel with an empty string disappears from the footer, the
mobile menu and the contact card. Never point one at a service homepage. A
dead link costs more than a missing icon.

Reviews: `REVIEWS` holds the real Google reviews copied by hand, with
`REVIEWS_CAPTURED` recording the date. Google shows ages rather than dates,
so each review is stored by the month it was left. Refresh these every few
months or they will read as stale.

## The contact form

The React form in `src/components/RequestForm.jsx` posts to Netlify Forms
under the name `cleaning-request`. Netlify detects forms by scanning the
built HTML at deploy time, so `index.html` carries a hidden static copy of
the same form. **Do not delete it** or submissions stop working.

Netlify uses the field named `email` as the reply address, so replying from
info@etileni2.com goes back to the customer. The notification itself is a
dashboard setting: Netlify, Forms, Form notifications, add an email
notification to info@etileni2.com.

This form only exists on Netlify. On any other host it needs replacing.

## Deploying

**Netlify.** `netlify.toml` holds the build command, the SPA redirect and the
cache headers. Connect the repo and it builds on push.

**Apache or LiteSpeed, Hostinger included.** `public/.htaccess` is copied into
`dist` on build and carries the SPA rewrite, cache headers and compression.
Without it a hard refresh on `/pricing` returns 404. Hostinger's Git feature
does not run a build, it serves the repo files as they are, so either commit
the built `dist` to a branch it watches or build in CI and upload `dist`.

## Still outstanding

- The site is English only. The customers are in Prishtina.
- Photography. Every media slot on the site is empty.
- Per page titles and meta descriptions. All pages currently share one.
- Only the home page has an `h1`.
- No `LocalBusiness` structured data, no `sitemap.xml`, no `robots.txt`.
- The full price list. The site says 94 items and shows eight.
- Facebook, TikTok and the YouTube channel URL.
- Privacy and Terms have not been reviewed by a lawyer.
